/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "stm32l476xx.h"

// create a led delay. Just a rough estimate
// for one second delay
#define LEDDELAY    1000000


/*************************************************
* function declarations
*************************************************/
int main(void);
void delay(volatile uint32_t s);

int main(void)
{
	// Enable GPIOA Peripheral Clock (bit 0 in AHB2ENR register)
	RCC->AHB2ENR = 0x00000001;

	// Make GPIOA Pin5 as output pin (bits 1:0 in MODER register)
		GPIOA->MODER &= 0xFFFFF3FF;		// Clear bits 11, 10 for P5
		GPIOA->MODER |= 0x00000400;		// Write 01 to bits 11, 10 for P5

	// Set GPIOA Pin5 to 1 (bit 5 in ODR register)
		GPIOA->ODR |= 0x0020;			// write 1 to pin 5

  while (1)
  {
		// Set a Delay
		delay(LEDDELAY);

		// Set GPIOA Pin5 to 0 (bit 5 in ODR register)
		GPIOA->ODR ^= (1 << 5);			// write 0 to pin 5
  }

}

// A simple and not accurate delay function
// that will change the speed based on the optimization settings
void delay(volatile uint32_t s)
{
    for(s; s>0; s--){
        // Do nothing
    }
}
